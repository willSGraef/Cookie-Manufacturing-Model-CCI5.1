def ints_to_float(high, low):
    from java.lang import Float
    combined = ((high & 0xFFFF) << 16) | (low & 0xFFFF)
    return Float.intBitsToFloat(combined)